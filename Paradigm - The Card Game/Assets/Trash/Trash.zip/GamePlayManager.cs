﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using DataBase;


//public class GamePlayManager : MonoBehaviour {

//    // Use this for initialization
//    public GameObject overlay;
//    public GameObject canvas;
//    Player human = new Player(GlobalPlayerDeck.getPlayerDeck());
//    Player ai = new Player(GlobalPlayerDeck.getPlayerDeck());

//    Deck debugDeck = new Deck();


//    void Start ()
//    {
        
//        Gamestart(human, ai);	
//	}

//    void Gamestart(Player human, Player ai)
//    {
//        debugDeckFunction();
//        setBarriers(human);
//        print("still coroutineing");
//    }



//    void setBarriers(Player p)
//    {
//        GameObject ovClone = Instantiate(overlay, canvas.transform, true);
//        ovClone.GetComponent<RectTransform>().SetParent(canvas.transform, false);
//        ovClone.GetComponentInChildren<OverlayPanel>().startBarrierSelection(p);
//        StartCoroutine(ovClone.GetComponentInChildren<OverlayPanel>().coroutineTest(p));
//        print("Whebn dp i print");
//	}

//    void debugDeckFunction()
//    {
//        List<Card> cardPool = CardDataBase.getCardCollection();
//        print(cardPool.Count); 

//        for(int i = 0; i<cardPool.Count; i++)
//        {
//            debugDeck.addCard(cardPool[Random.Range(0,cardPool.Count)]);
//        }

//        print("Debug Deck size: " + debugDeck.getDeckSize());
//        GlobalPlayerDeck.setPlayerDeck(debugDeck);
//    }

//    public void testingScript()
//    {
//        print("I wonder if this works");
//    }
//    public Player getPlayer1()
//    {
//        return human;
//    }
   
//}
