﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AttackStateAI : ITurnState
{
    private readonly AITurnPattern turnPhase;
    private int normalCardPlays;
    private Vector3 initialPositionOnField;
    private GameObject playFieldObject;
    private GameObject cardPrefab;
    private GameObject canvas;
    private Sprite onSelectSprite;
    private Sprite onDeSelectSprite;
    private Player player;

    public AttackStateAI()
    {

    }

    public void UpdateState()
    {

    }

    public void ToBarrierSelectState()
    {

    }

    public void ToLandscapeSelectState()
    {

    }

    public void ToDrawState()
    {

    }

    public void ToMainPhaseState()
    {

    }

    public void ToAttackState()
    {

    }

    public void ToCrystallizeState()
    {

    }

    public void ToEndTurnState()
    {

    }

    public void ToDimTwistState()
    {

    }
}
