﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class BarrierSelectStateAI : ITurnState
{
    private readonly AITurnPattern turnPhase;
    private bool selected;
    private Player player;
  
    public BarrierSelectStateAI(Player p, AITurnPattern t)
    {
        selected = false;     
        player = p;
        turnPhase = t;
    }

    public void UpdateState()
    {
        if(!selected)
        {
            selected = true;
            selectCard();
            player.setBarrierSelectionStatus(true);
        }

        ToLandscapeSelectState();
    }

    public void ToBarrierSelectState()
    {
        Debug.Log("Can't transition to the State it's already in");
    }

    public void ToLandscapeSelectState()
    {
        turnPhase.currentState = turnPhase.landscapeSelectState;
    }

    public void ToDrawState()
    {
        Debug.Log("Can't transition to this state from Barrier select");
    }

    public void ToMainPhaseState()
    {
        Debug.Log("Can't transition to this state from Barrier select");
    }

    public void ToAttackState()
    {
        Debug.Log("Can't transition to this state from Barrier select");
    }

    public void ToCrystallizeState()
    {
        Debug.Log("Can't transition to this state from Barrier select");
    }

    public void ToEndTurnState()
    {
        Debug.Log("Can't transition to this state from Barrier select");
    }

    public void ToDimTwistState()
    {
        Debug.Log("Can't transition to this state from Barrier select");
    }

    void selectCard()
    {
        while(player.getBarriers() < 12)
        {
            Card toAdd = GlobalPlayerDeck.getAIPlayerDeck().getDeck()[Random.Range(0, GlobalPlayerDeck.getAIPlayerDeck().getDeck().Count)];
            while((toAdd.getType().Contains("landscape")) || (toAdd.getType().Contains("Philosopher")) || (toAdd.getAbility().Contains("Majesty")))
            {
                toAdd = GlobalPlayerDeck.getAIPlayerDeck().getDeck()[Random.Range(0, GlobalPlayerDeck.getAIPlayerDeck().getDeck().Count)];
            }
            //Debug.Log(toAdd.getType());
            player.AddBarrier(toAdd);
            player.removeFromDeck(toAdd);
        }
        
    }//end SelectCard

 

}
