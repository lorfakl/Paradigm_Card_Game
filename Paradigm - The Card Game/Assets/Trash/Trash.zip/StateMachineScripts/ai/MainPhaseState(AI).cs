﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class MainPhaseStateAI : ITurnState
{
    private readonly AITurnPattern turnPhase;
    private int normalCardPlays;
    private int attackChance;
    private int playerAttkChance;
    private int endTurnChance;
    private int cardPlayChance;
    private int chooseCardChance;
    private int crystallizeChance;
    private Vector3 initialPositionOnField;
    private GameObject playFieldObject;
    private GameObject cardPrefab;
    private GameObject canvas;
    private Player player;

    public MainPhaseStateAI(GameObject playfield, GameObject cardfab, Player p, AITurnPattern t)
    {
        initialPositionOnField = new Vector3(0.03f, 0.24f);
        normalCardPlays = 0;
        playFieldObject = playfield;
        cardPrefab = cardfab;
        player = p;
        turnPhase = t;

}

    public void UpdateState()
    {
        timer(Random.Range(1f, 5.2f));
        while(normalCardPlays < 3)
        {
            selectCard();
        }

    }

    public void ToBarrierSelectState(){Debug.Log("Can't transition to this state from Main Phase");}
    public void ToLandscapeSelectState(){Debug.Log("Can't transition to this state from Main Phase");}
    public void ToDrawState(){Debug.Log("Can't transition to this state from Main Phase");}
    public void ToMainPhaseState(){Debug.Log("Can't transition to the State it's already in");}

    public void ToAttackState()
    {
        turnPhase.currentState = turnPhase.attackState;
    }

    public void ToCrystallizeState()
    {
        turnPhase.currentState = turnPhase.crystallizeState;
    }

    public void ToEndTurnState()
    {
        normalCardPlays = 0;
        turnPhase.currentState = turnPhase.endTurnState;
    }
    public void ToDimTwistState(){Debug.Log("Can't transition to this state from Main Phase"); }

    GameObject createCardObject(Card c)
    {
        GameObject cardObject = GameObject.Instantiate(cardPrefab, playFieldObject.transform.position, Quaternion.identity);
        //RectTransform cardRectTransform = cardObject.GetComponent<RectTransform>();
        //cardRectTransform.SetParent(playFieldObject.transform, false);
        cardObject.GetComponent<cardDetailsAddOn>().setExpandedCard(c);
        cardObject.GetComponentInChildren<Canvas>().overrideSorting = true;
        Text[] textEdit = cardObject.GetComponentsInChildren<Text>();
        textEdit[0].text = c.getName();
        textEdit[1].text = c.getEffect();
        //objectsToDelete.Add(cardObject);
     

        return cardObject;
    }//end createCardObjects function

    void selectCard()
    {
        //Vector3 originalInitialPostion = initialPositionOnField;
        chooseCardChance = Random.Range(0, player.getPlayerHand().Count);
        GameObject card = createCardObject(player.getPlayerHand()[chooseCardChance]);
        Debug.Log("Name of AI Played card " + card.GetComponent<cardDetailsAddOn>().getExpandedCard().getName() + " Card Type: " + card.GetComponent<cardDetailsAddOn>().getExpandedCard().getType());
        Debug.Log("Normal plays " + normalCardPlays);
        if ((card.GetComponent<cardDetailsAddOn>().getExpandedCard().getType().Contains("Accessor")) || (card.GetComponent<cardDetailsAddOn>().getExpandedCard().getType().Contains("Elemental")))
        {
            while(normalCardPlays < 3)
            {
                card.transform.localPosition = initialPositionOnField;
                PositionCard(card);
                normalCardPlays++;
                Debug.Log("Card Played: " + card.GetComponent<cardDetailsAddOn>().getExpandedCard().getName() + " (AI)");
                Debug.Log( normalCardPlays + " (AI)");
            }
            Debug.Log("You can no longer preform a normal spawn");
            return;
        }
        else if(card.GetComponent<cardDetailsAddOn>().getExpandedCard().getType()=="Element")
            {
                if(player.CanUseElements())
                {
                    PositionCard(card);
                    card.transform.localPosition = initialPositionOnField;
                }
                Debug.Log("Can't use Elements you have no Elementals on your field");
                return;
            }


        /*else
            {
                player.AddToField(card);
                card.transform.localPosition = initialPositionOnField;
            }*/
        
        
    }//end SelectCard

    void PositionCard(GameObject cardSelected)
    {
        //Debug.Log("object on field" + player.getPlayerCardsOnField().Count);
        foreach (GameObject g in player.getPlayerCardsOnField())
        {
            Vector3 modPosition = g.transform.localPosition;
            modPosition.x -= 2f;
            // Debug.Log("Pre mod " + g.transform.localPosition);
            g.transform.localPosition = modPosition;
            //Debug.Log("Post mod " + g.transform.localPosition);
        }//end foreach

        player.AddToField(cardSelected);
        cardSelected.transform.localPosition = initialPositionOnField;
        //initialPositionOnField.x += 2f;
        //Debug.Log("Pre mod " + cardSelected.transform.localPosition);
        if(player.getPlayerCardsOnField().Count > 4)
        {
            foreach(GameObject obj in player.getPlayerCardsOnField())
            {
                Vector3 modPosition = obj.transform.localPosition;
                modPosition.x += 3f;
                obj.transform.localPosition = modPosition;
            }
        }
            
       
        //Debug.Log("Post mod " + cardSelected.transform.localPosition);
    }

    IEnumerator timer(float timeWait)
    {
        Debug.Log("I am thinking about my next move. Hmmm...");
        yield return new WaitForSeconds(timeWait);
    }
}
