﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using DataBase;

public class AITurnPattern : MonoBehaviour {

    public GameObject managerScript;
    public GameObject playfield;
    public GameObject card;
    public Sprite spChangeOnSelect;
    public Sprite spOnDeselect;

    Deck debugDeck = new Deck();
    Player player;
    [HideInInspector] public ITurnState currentState;
    [HideInInspector] public BarrierSelectStateAI barrierSelectState;
    [HideInInspector] public LandscapeSelectStateAI landscapeSelectState;
    [HideInInspector] public DrawStateAI drawState;
    [HideInInspector] public MainPhaseStateAI mainPhaseState;
    [HideInInspector] public AttackStateAI attackState;
    [HideInInspector] public CrystallizeStateAI crystallizeState;
    [HideInInspector] public EndTurnStateAI endTurnState;
    [HideInInspector] public DimensionTwistStateAI dtState;
    
    // Use this for initialization
    void Awake ()
    {
        //initialize all above Hidden Objects
        debugDeckFunction();
        GlobalPlayerDeck.getAIPlayerDeck().shuffleDeck();
        player = managerScript.GetComponent<GameManager>().sendAIPlayer();
        player.setDeck(GlobalPlayerDeck.getAIPlayerDeck());
        barrierSelectState = new BarrierSelectStateAI(player, this);
        landscapeSelectState = new LandscapeSelectStateAI(player, this);
        drawState = new DrawStateAI(player, this);
        mainPhaseState = new MainPhaseStateAI(playfield, card, player, this);
      
        //mainPhaseState = new MainPhaseStateAI(playfield, cardPrefab, spChangeOnSelect, spOnDeselect, player, this); 	
	}
	
    void Start()
    {
        //currentState = barrierSelectState;
    }

	// Update is called once per frame
	void Update ()
    {
        //currentState.UpdateState();	
	}

    void debugDeckFunction()
    {
        List<Card> cardPool = CardDataBase.getCardCollection();
        //print(cardPool.Count);

        for (int i = 0; i < cardPool.Count; i++)
        {
            debugDeck.addCard(cardPool[Random.Range(0, cardPool.Count)]);
        }

        print("Debug Deck size: " + debugDeck.getDeckSize());
        GlobalPlayerDeck.setAIPlayerDeck(debugDeck);
    }

    void OnMouseOver()
    {
        print("Mopsut");
    }
}
