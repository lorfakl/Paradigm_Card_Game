﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using DataBase;

public class LandscapeSelectStateAI : ITurnState
{
    private readonly AITurnPattern turnPhase;
    private bool selected;
    private Player player;
    

    public LandscapeSelectStateAI(Player p, AITurnPattern t)
    {
        player = p;
        turnPhase = t;
        selected = false;
    }

    public void UpdateState()
    {
        if(!selected)
        {
            selected = true;
            selectCard();
            Debug.Log("Got my landscape");
        }

        
        ToDrawState();

    }

    public void ToBarrierSelectState()
    {
        Debug.Log("Can't transition to this state from landscape select");
    }

    public void ToLandscapeSelectState()
    {
        Debug.Log("Can't transition to the State it's already in");
    }

    public void ToDrawState()
    {
        turnPhase.currentState = turnPhase.drawState;
    }

    public void ToMainPhaseState()
    {
        Debug.Log("Can't transition to this state from landscape select");
    }

    public void ToAttackState()
    {
        Debug.Log("Can't transition to this state from landscape select");
    }

    public void ToCrystallizeState()
    {
        Debug.Log("Can't transition to this state from landscape select");
    }

    public void ToEndTurnState()
    {
        Debug.Log("Can't transition to this state from landscape select");
    }

    public void ToDimTwistState()
    {
        Debug.Log("Can't transition to this state from landscape select");
    }

    void selectCard()
    {
        if(GlobalPlayerDeck.getAIPlayerDeck().getLandscapesInDeck().Count == 0)
        {
            foreach( Card c in CardDataBase.getCardCollection())
            {
                if(c.getType() == "Landscape")
                {
                    if(GlobalPlayerDeck.getAIPlayerDeck().addCard(c))
                    {
                        break;
                    }
                }
            }
        }
            
           
        player.setTCLandscapeCard(GlobalPlayerDeck.getAIPlayerDeck().getLandscapesInDeck()[Random.Range(0, GlobalPlayerDeck.getAIPlayerDeck().getLandscapesInDeck().Count)]);
        Debug.Log("Name of Landscape" + player.getTCLandscapeCard().getName());    
   
        
    }//end SelectCard

}
