﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class DrawStateAI : ITurnState
{
    private readonly AITurnPattern turnPhase;
    private bool cardsDisplayed;
    private bool initialDraw;
    private Player player;
    [HideInInspector] public int numberOfCardsToDraw;

    public DrawStateAI(Player p, AITurnPattern t)
    {
        turnPhase = t;
        player = p;
        initialDraw = false;
        numberOfCardsToDraw = 6;
    }

    public void UpdateState()
    {
        if (!initialDraw)
        {
            initialDraw = true;
            player.RemoveCardsOnGameStart();
            DrawCards();

        }
        else
        {
            player.DrawFromDeck();
        }
        Debug.Log("Move to MainPhase(AI)");
        ToMainPhaseState();
    }

    public void ToBarrierSelectState()
    {
        Debug.Log("Can't transition to this state from draw phase");
    }

    public void ToLandscapeSelectState()
    {
        Debug.Log("Can't transition to this state from draw phase");
    }

    public void ToDrawState()
    {
        Debug.Log("Can't transition to the State it's already in");
    }

    public void ToMainPhaseState()
    {
        turnPhase.currentState = turnPhase.mainPhaseState;
    }

    public void ToAttackState()
    {
        Debug.Log("Can't transition to this state from draw phase");
    }

    public void ToCrystallizeState()
    {
        Debug.Log("Can't transition to this state from draw phase");
    }

    public void ToEndTurnState()
    {
        Debug.Log("Can't transition to this state from draw phase");
    }

    public void ToDimTwistState()
    {
        Debug.Log("Can't transition to this state from draw phase");
    }

    void DrawCards()
    {
        for(int i = 0; i < 6; i++)
        {
            player.AddToHand(GlobalPlayerDeck.getAIPlayerDeck().getDeck()[Random.Range(0, GlobalPlayerDeck.getAIPlayerDeck().getDeck().Count)]);
            Debug.Log("AI hand " + player.getPlayerHand()[i].getName());
        }
    }
    
}
