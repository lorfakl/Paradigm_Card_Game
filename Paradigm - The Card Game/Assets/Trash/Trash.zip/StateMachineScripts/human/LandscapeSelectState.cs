﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class LandscapeSelectState : ITurnState
{
    private readonly StateTurnPattern turnPhase;
    private bool showCards;
    private bool selected;
    private bool initialSetup;
    private GameObject overlayPanelPrefab;
    private GameObject cardPrefab;
    private GameObject canvas;
    private Sprite onSelectSprite;
    private Sprite onDeSelectSprite;
    private Player player;
    List<GameObject> objectsToDelete = new List<GameObject>();

    public LandscapeSelectState(GameObject canvas, GameObject overlayPrefab, GameObject cardPrefab, Sprite onSelect, Sprite onDeselect, Player p, StateTurnPattern t)
    {
        initialSetup = false;
        showCards = false;
        selected = false;
        onSelectSprite = onSelect;
        onDeSelectSprite = onDeselect;
        overlayPanelPrefab = overlayPrefab;
        this.cardPrefab = cardPrefab;
        this.canvas = canvas;
        player = p;
        turnPhase = t;

    }

    public void UpdateState()
    {
        Debug.Log("Landscape phase" + initialSetup);

        if (!initialSetup)
        {
            Debug.Log("Only ONCE!");
            initialSetup = true;
            createInitialObjects();
            //instaniate neccessary objects
        }

        if(!showCards)
        {
            showCards = true;
            showLandscapeCards(player);
            //instaniate the overlay, search for the landscape cards, print the cards

        }
        //select function runs per update call
        selectCard(player);

        if(player.getTCLandscapeCard().getName() != null)
        {
            //destroy overlay and other now supurfluous objects
            destroyUnNeededObjects();
            ToDrawState();
        }

    }

    public void ToBarrierSelectState()
    {
        Debug.Log("Can't transition to this state from landscape select");
    }

    public void ToLandscapeSelectState()
    {
        Debug.Log("Can't transition to the State it's already in");
    }

    public void ToDrawState()
    {
        turnPhase.currentState = turnPhase.drawState;
    }

    public void ToMainPhaseState()
    {
        Debug.Log("Can't transition to this state from landscape select");
    }

    public void ToAttackState()
    {
        Debug.Log("Can't transition to this state from landscape select");
    }

    public void ToCrystallizeState()
    {
        Debug.Log("Can't transition to this state from landscape select");
    }

    public void ToEndTurnState()
    {
        Debug.Log("Can't transition to this state from landscape select");
    }

    public void ToDimTwistState()
    {
        Debug.Log("Can't transition to this state from landscape select");
    }

    void createInitialObjects()
    {
        GameObject ovClone = GameObject.Instantiate(overlayPanelPrefab, canvas.transform, true);
        ovClone.GetComponent<RectTransform>().SetParent(canvas.transform, false);
        objectsToDelete.Add(ovClone);
    }

    void showLandscapeCards(Player p)
    {
        GameObject cardObject = null;
        Vector3 position = new Vector3(-47.0f, 3.95f);
        float originalX = position.x;
        int r = 0;
        Debug.Log(GlobalPlayerDeck.getPlayerDeck().getDeckSize());
        foreach (Card card in GlobalPlayerDeck.getPlayerDeck().getLandscapesInDeck())
        {
            
            cardObject = createCardObject(card); //make it
            cardObject.transform.localPosition = position;//move it
            if (r < 6)
            {
                r++;
                position.x += 16.4f;
                //Debug.Log("make new colummn");
            }
                else
                {
                    position.y += -4f;
                    position.x = originalX;
                    r = 0;
                    //Debug.Log("make new row");
                }
        }
    }//end show Barrier function


    GameObject createCardObject(Card c)
    {
        GameObject cardObject = GameObject.Instantiate(cardPrefab, overlayPanelPrefab.transform.position, Quaternion.identity);
        //RectTransform cardRectTransform = cardObject.GetComponent<RectTransform>();
        //cardRectTransform.SetParent(overlayPanelPrefab.transform, false);
        cardObject.GetComponent<cardDetailsAddOn>().setExpandedCard(c);
        cardObject.GetComponentInChildren<Canvas>().overrideSorting = true;
        Text[] textEdit = cardObject.GetComponentsInChildren<Text>();
        textEdit[0].text = c.getName();
        textEdit[1].text = c.getEffect();
        objectsToDelete.Add(cardObject);
        //Debug.Log("Yahhh Creating");

        return cardObject;
    }//end createCardObjests function

    void selectCard(Player p)
    {

        if (Input.GetMouseButtonUp(0))
        {
            Ray ray = Camera.main.ScreenPointToRay(Input.mousePosition);
            RaycastHit hit;
            if (Physics.Raycast(ray, out hit))
            {
                GameObject cardSelected = hit.transform.gameObject;
                if (!selected)
                {
                    cardSelected.GetComponentInChildren<SpriteRenderer>().sprite = onSelectSprite;
                    p.setTCLandscapeCard(cardSelected.GetComponent<cardDetailsAddOn>().getExpandedCard());
                    Debug.Log("Player Landscape choice: " + p.getTCLandscapeCard().getName());
                }
                else if (selected)
                {
                    cardSelected.GetComponentInChildren<SpriteRenderer>().sprite = onDeSelectSprite;
                    p.removeTCLandscapeCard();
                    Debug.Log("Player Landscape choice: " + p.getTCLandscapeCard().getName());
                }

            }//end Raycast IF
        }//end Input IF
    }//end SelectCard

    void destroyUnNeededObjects()
    {
        foreach (GameObject g in objectsToDelete)
        {
            GameObject.Destroy(g);
        }
    }
}
