﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using DataBase;

public class StateTurnPattern : MonoBehaviour {

    public GameObject managerScript;
    public GameObject CanvasToBeParent;
    public GameObject overlayUI;
    public GameObject cardPrefab;
    public GameObject handObject;
    public GameObject playfield;
    public Sprite spChangeOnSelect;
    public Sprite spOnDeselect;

    Deck debugDeck = new Deck();
    Player player;
    [HideInInspector] public ITurnState currentState;
    [HideInInspector] public BarrierSelectState barrierSelectState;
    [HideInInspector] public LandscapeSelectState landscapeSelectState;
    [HideInInspector] public DrawState drawState;
    [HideInInspector] public MainPhaseState mainPhaseState;
    [HideInInspector] public AttackState attackState;
    [HideInInspector] public CrystallizeState crystallizeState;
    [HideInInspector] public EndTurnState endTurnState;
    [HideInInspector] public DimensionTwistState dtState;
    
    // Use this for initialization
    void Awake ()
    {
        //initialize all above Hidden Objects
        debugDeckFunction();
        GlobalPlayerDeck.getPlayerDeck().shuffleDeck();
        player = managerScript.GetComponent<GameManager>().sendHumanPlayer();
        player.setDeck(GlobalPlayerDeck.getPlayerDeck());
        barrierSelectState = new BarrierSelectState(CanvasToBeParent, overlayUI, cardPrefab, spChangeOnSelect, spOnDeselect, player, this);
        landscapeSelectState = new LandscapeSelectState(CanvasToBeParent, overlayUI, cardPrefab, spChangeOnSelect, spOnDeselect, player, this);
        drawState = new DrawState(cardPrefab, handObject, player, this);
        mainPhaseState = new MainPhaseState(playfield, cardPrefab, spChangeOnSelect, spOnDeselect, player, this);
       
    }
	
    void Start()
    {
        //currentState = barrierSelectState;
    }

	// Update is called once per frame
	void Update ()
    {
        //currentState.UpdateState();	
	}

    void debugDeckFunction()
    {
        List<Card> cardPool = CardDataBase.getCardCollection();
        //print(cardPool.Count);

        for (int i = 0; i < cardPool.Count; i++)
        {
            debugDeck.addCard(cardPool[Random.Range(0, cardPool.Count)]);
        }

        print("Debug Deck size: " + debugDeck.getDeckSize());
        GlobalPlayerDeck.setPlayerDeck(debugDeck);
    }

    void OnMouseOver()
    {
        print("Mopsut");
    }
}
