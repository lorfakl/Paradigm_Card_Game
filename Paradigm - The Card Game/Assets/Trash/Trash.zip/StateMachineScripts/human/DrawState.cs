﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class DrawState : ITurnState
{
    private readonly StateTurnPattern turnPhase;
    private bool cardsDisplayed;
    private bool initialDraw;
    private Player player;
    private GameObject playerHandPrefab;
    private GameObject cardPrefab;
    List<GameObject> objectsToDelete = new List<GameObject>();
    [HideInInspector] public int numberOfCardsToDraw;

    public DrawState(GameObject cardFab, GameObject handPrefab, Player p, StateTurnPattern t)
    {
        turnPhase = t;
        player = p;
        playerHandPrefab = handPrefab;
        cardPrefab = cardFab;
        cardsDisplayed = false;
        initialDraw = false;
        numberOfCardsToDraw = 6;
    }

    public void UpdateState()
    {
        if (!initialDraw)
        {
            initialDraw = true;
            if (!cardsDisplayed)
            {
                cardsDisplayed = true;
                player.RemoveCardsOnGameStart();
                displayCards();//*******
            }
        }
        else
        {
            displayCard(); //*******

        }
        Debug.Log("Move to NExt Sate");
        ToMainPhaseState();
    }

    public void ToBarrierSelectState()
    {
        Debug.Log("Can't transition to this state from draw phase");
    }

    public void ToLandscapeSelectState()
    {
        Debug.Log("Can't transition to this state from draw phase");
    }

    public void ToDrawState()
    {
        Debug.Log("Can't transition to the State it's already in");
    }

    public void ToMainPhaseState()
    {
        turnPhase.currentState = turnPhase.mainPhaseState;
    }

    public void ToAttackState()
    {
        Debug.Log("Can't transition to this state from draw phase");
    }

    public void ToCrystallizeState()
    {
        Debug.Log("Can't transition to this state from draw phase");
    }

    public void ToEndTurnState()
    {
        Debug.Log("Can't transition to this state from draw phase");
    }

    public void ToDimTwistState()
    {
        Debug.Log("Can't transition to this state from draw phase");
    }

    void displayCards()
    {
        GameObject cardObject = null;
        Vector3 position = new Vector3(-46.3f, -24.7f);
        player.DrawFromDeck(numberOfCardsToDraw); //*******
        foreach (Card c in player.getPlayerHand())
        {
            cardObject = createCardObject(c);
            cardObject.transform.localPosition = position;
            player.AddToHand(cardObject);
            position.x += 16f;
        }
    }

    void displayCard()
    {
        player.DrawFromDeck();
        Vector3 endOfHandPosition = new Vector3();
/********/ endOfHandPosition = player.getPlayerCardsInHand()[player.getPlayerCardsInHand().Count - 1].transform.position;  //See script notes below
        GameObject cardObject = createCardObject(player.getPlayerHand()[player.getPlayerHand().Count - 1]);     //See script notes below
        endOfHandPosition.x += 2f;
        cardObject.transform.localPosition = endOfHandPosition;
    }

    GameObject createCardObject(Card c)
    {
        GameObject cardObject = GameObject.Instantiate(cardPrefab, playerHandPrefab.transform.position, Quaternion.identity);
        //cardObject.GetComponent<RectTransform>().SetParent(playerHandPrefab.transform, false);
        cardObject.GetComponent<cardDetailsAddOn>().setExpandedCard(c);
        cardObject.GetComponentInChildren<Canvas>().overrideSorting = true;
        Text[] textEdit = cardObject.GetComponentsInChildren<Text>();
        textEdit[0].text = c.getName();
        textEdit[1].text = c.getEffect();
        objectsToDelete.Add(cardObject);
        

        return cardObject;
    }//end createCardObjests function


    /*
     Script Notes:
     line 107 says get the Vector3 position of the card that is at the end of the player's hand. To do that I needed to return the entire
     list of objects and navigate to the object at the end of that list and return that object's position
     line 108 does the same thing in terms of accessing a specific element in the list returned from getPlayerHand() but instead it passes that 
     Card into a function to map the card's data to a gameobject and instaniate that game object
     
     
     */
}
