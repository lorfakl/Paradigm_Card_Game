﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DimensionTwistState : ITurnState
{

    public void UpdateState()
    {

    }

    public void ToBarrierSelectState()
    {

    }

    public void ToLandscapeSelectState()
    {

    }

    public void ToDrawState()
    {

    }

    public void ToMainPhaseState()
    {

    }

    public void ToAttackState()
    {

    }

    public void ToCrystallizeState()
    {

    }

    public void ToEndTurnState()
    {

    }

    public void ToDimTwistState()
    {

    }
}
