﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class MainPhaseState : ITurnState
{
    private readonly StateTurnPattern turnPhase; //why is this read only?
    private int normalCardPlays;
    private Vector3 initialPositionOnField;
    private GameObject playFieldObject;
    private GameObject cardPrefab;
    private Sprite onSelectSprite;
    private Sprite onDeSelectSprite;
    private Player player;

    public MainPhaseState(GameObject playfield, GameObject cardfab, Sprite onhover, Sprite offhover, Player p, StateTurnPattern t)
    {
        initialPositionOnField = new Vector3(0.03f, 2.2f);
        normalCardPlays = 0;
        playFieldObject = playfield;
        cardPrefab = cardfab;
        onSelectSprite = onhover;
        onDeSelectSprite = offhover;
        player = p;
        turnPhase = t;
        
    }

    public void UpdateState() //this runs every frame called from Update
    {
        player.setSetupStatus(true);
        selectCard(player);
        Debug.Log("normal spawns" + normalCardPlays);

        if (Input.GetKeyUp("e"))
        {
            Debug.Log("I end my turn");
            ToEndTurnState();
        }

        if (Input.GetKeyUp("c"))
        {
            Debug.Log("Lets Crystalize!!!");
            ToCrystallizeState();
        }

        if (Input.GetKeyUp("a"))
        {
            Debug.Log("Lets Attack!!!");
            ToAttackState();
        }
    }

    public void ToBarrierSelectState()
    {
        Debug.Log("Can't transition to this state from Main Phase");
    }

    public void ToLandscapeSelectState()
    {
        Debug.Log("Can't transition to this state from Main Phase");
    }

    public void ToDrawState()
    {
        Debug.Log("Can't transition to this state from Main Phase");
    }

    public void ToMainPhaseState()
    {
        Debug.Log("Can't transition to the State it's already in");
    }

    public void ToAttackState()
    {
        turnPhase.currentState = turnPhase.attackState;
    }

    public void ToCrystallizeState()
    {
        turnPhase.currentState = turnPhase.crystallizeState;
    }

    public void ToEndTurnState()
    {
        normalCardPlays = 0;
        turnPhase.currentState = turnPhase.endTurnState;
    }

    public void ToDimTwistState()
    {
        Debug.Log("Can't transition to this state from Main Phase");
    }


    GameObject createCardObject(Card c)
    {
        GameObject cardObject = GameObject.Instantiate(cardPrefab, playFieldObject.transform.position, Quaternion.identity);
        //RectTransform cardRectTransform = cardObject.GetComponent<RectTransform>();
        //cardRectTransform.SetParent(playFieldObject.transform, false);
        cardObject.GetComponent<cardDetailsAddOn>().setExpandedCard(c);
        cardObject.GetComponentInChildren<Canvas>().overrideSorting = true;
        Text[] textEdit = cardObject.GetComponentsInChildren<Text>();
        textEdit[0].text = c.getName();
        textEdit[1].text = c.getEffect();
        //objectsToDelete.Add(cardObject);
     

        return cardObject;
    }//end createCardObjects function

    void selectCard(Player p)
    {
        if (Input.GetMouseButtonUp(0))
        {
            Ray ray = Camera.main.ScreenPointToRay(Input.mousePosition);
            RaycastHit hit;

            if (Physics.Raycast(ray, out hit))
            {
                GameObject cardSelected = hit.transform.gameObject;
                //Debug.Log("Hittttt");
                Debug.Log("Card Type " + cardSelected.GetComponent<cardDetailsAddOn>().getExpandedCard().getType());
                if (cardSelected.GetComponent<cardDetailsAddOn>().getExpandedCard().getType().Contains("Element")) //change to equals
                {
                    if (player.CanUseElements() || cardSelected.GetComponent<cardDetailsAddOn>().getExpandedCard().getType().Contains("Elemental"))//shouldnt this be if(can play elements OR has elementals on field)
                    {
                        PositionCard(cardSelected); 
                        cardSelected.GetComponent<cardDetailsAddOn>().getExpandedCard().setPlayStatus(true);
                        return;
                    }
                    else
                    {
                        Debug.Log("Can't use Elements you have no Elementals on your field");
                        return;
                    }
                }

                else if ((cardSelected.GetComponent<cardDetailsAddOn>().getExpandedCard().getType().Contains("Accessor")) || (cardSelected.GetComponent<cardDetailsAddOn>().getExpandedCard().getType().Contains("Elemental")))
                {
                    if (normalCardPlays > 3)
                    {
                        Debug.Log("You can no longer preform a normal spawn");
                        return;
                    }

                    //Debug.Log("Its an accessor or elemental");
                    PositionCard(cardSelected);
                    normalCardPlays++;
                    cardSelected.GetComponent<cardDetailsAddOn>().getExpandedCard().setPlayStatus(true);
                    return;
                }

                PositionCard(cardSelected);
            }//end Raycast IF
        }//end Input IF
    }//end SelectCard

    void PositionCard(GameObject cardSelected)
    {
        //Debug.Log("object on field" + player.getPlayerCardsOnField().Count);
        foreach (GameObject g in player.getPlayerCardsOnField())
        {
            Vector3 modPosition = g.transform.localPosition;
            modPosition.x -= 16f;
            // Debug.Log("Pre mod " + g.transform.localPosition);
            g.transform.localPosition = modPosition;
            //Debug.Log("Post mod " + g.transform.localPosition);
        }//end foreach

        player.AddToField(cardSelected);
        cardSelected.transform.localPosition = initialPositionOnField;
        //initialPositionOnField.x += 2f;
        //Debug.Log("Pre mod " + cardSelected.transform.localPosition);
        if(player.getPlayerCardsOnField().Count > 4)
        {
            foreach(GameObject obj in player.getPlayerCardsOnField())
            {
                Vector3 modPosition = obj.transform.localPosition;
                modPosition.x += 32f;
                obj.transform.localPosition = modPosition;
            }
        }
            
       
        //Debug.Log("Post mod " + cardSelected.transform.localPosition);
    }
}
