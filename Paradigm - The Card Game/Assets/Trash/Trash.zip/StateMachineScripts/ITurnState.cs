﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public interface ITurnState 
{

    void UpdateState();

    void ToBarrierSelectState();

    void ToLandscapeSelectState();

    void ToDrawState();

    void ToMainPhaseState();

    void ToAttackState();

    void ToCrystallizeState();

    void ToEndTurnState();

    void ToDimTwistState();
}
