﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class selectCards : MonoBehaviour {

    //public GameObject gameManager;
    public Sprite spChangeOnSelect;
    public Sprite spOnDeselect;
    bool selected;

    // Use this for initialization
    void Start ()
    {
        selected = false;
    }
	
	// Update is called once per frame
     void Update ()
    {
        selectCard();
    }

    
    public void selectCard()
    {
        
        if (Input.GetMouseButtonUp(0))
        {
            print("input");
            Ray ray = Camera.main.ScreenPointToRay(Input.mousePosition);
            print("fired a ray");
            print("SHould be false: " + selected);
            RaycastHit hit;
            if (Physics.Raycast(ray, out hit))
            {
                print("Something happened");
                GameObject cardSelected = hit.transform.gameObject;
                if (selected)
                {
                    print("SHould be true(if): " + selected);
                    cardSelected.GetComponentInChildren<SpriteRenderer>().sprite = spOnDeselect;
                    selected = false;
                    print("SHould be false(if): " + selected);
                }
                    else 
                    {
                        print("SHould be false(else): " + selected);
                        cardSelected.GetComponentInChildren<SpriteRenderer>().sprite = spChangeOnSelect;
                        selected = true;
                        print("SHould be true(else): " + selected);
                }
                //print(card.GetType());
            }
        }
    }
}
