﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

//public class OverlayPanel : MonoBehaviour {

//    public GameObject panel;
//    public GameObject cardPrefab;
//    public Sprite spChangeOnSelect;
//    public Sprite spOnDeselect;
//    public GamePlayManager script;
//    public bool settingBarriers = false;
//    public bool choosingCardsForTC = false;

//    bool selected;
//    Deck debugDeck = new Deck();
//    Player player = new Player();
//	// Use this for initialization
//	void Start ()
//    {
        
//        debugDeck = GlobalPlayerDeck.getPlayerDeck();
//       // startBarrierSelection(player);
//        selected = false;
//        //print("Yahhh");
//	}

//    /*void Update()
//    {
//        selectCard(player);
//        if(player.getBarriers() == 12)
//        {
//            return;
//        }
        
//    }*/
	
	
//	GameObject createCardObject(Card c)
//    {
//        GameObject cardObject = Instantiate(cardPrefab, panel.transform.position, Quaternion.identity);
//        RectTransform cardRectTransform = cardObject.GetComponent<RectTransform>();
//        cardRectTransform.SetParent(panel.transform, false);
//        cardObject.GetComponent<cardDetailsAddOn>().setExpandedCard(c);
//        cardObject.GetComponentInChildren<Canvas>().overrideSorting = true;
//        Text[] textEdit = cardObject.GetComponentsInChildren<Text>();
//        textEdit[0].text = c.getName();
//        textEdit[1].text = c.getEffect();
//        //print("Yahhh Creating");
        
//        return cardObject;
//	}

//    public void startBarrierSelection(Player p)
//    {
//        print("Whats going on");
//        settingBarriers = true;
//        GameObject cardObject = null;
//        Vector3 position = new Vector3(-9.10f, 3.95f);
//        float originalX = position.x;
//        int r = 0;
//        print("Whats going on2");
//        print(GlobalPlayerDeck.getPlayerDeck().getDeckSize());
//        foreach (Card card in GlobalPlayerDeck.getPlayerDeck().getDeck())
//        {
//            cardObject = createCardObject(card); //make it
//            cardObject.transform.localPosition = position;//move it
//            print("Whats going on3");
//            if (r < 6)
//            {
//                r++;
//                position.x += 3f;
//                //print("make new colummn");
//            }
//                else
//                {
//                    position.y += -4f;
//                    position.x = originalX;
//                    r = 0;
//                //print("make new row");
//                }
//        }
//        print("Whats going on4");

//        //StartCoroutine(coroutineTest(p));

//        print("When does this run?");
//    }//end PrintBarrierSelection

//    void selectCard(Player p)
//    {
        
//        if (Input.GetMouseButtonUp(0))
//        {
//            print("input");
//            Ray ray = Camera.main.ScreenPointToRay(Input.mousePosition);
//            print("fired a ray");
//            print("SHould be false: " + selected);
//            RaycastHit hit;
//            if (Physics.Raycast(ray, out hit))
//            {
//                print("Something happened");
//                GameObject cardSelected = hit.transform.gameObject;
//                if(!selected)
//                {
//                    cardSelected.GetComponentInChildren<SpriteRenderer>().sprite = spChangeOnSelect;
//                    p.AddBarrier(cardSelected.GetComponent<cardDetailsAddOn>().getExpandedCard());
//                    print("Player Barriers: " + p.getBarriers());
//                }
//                    else if(selected)
//                    {
//                        cardSelected.GetComponentInChildren<SpriteRenderer>().sprite = spOnDeselect;
//                        p.removeBarrier(cardSelected.GetComponent<cardDetailsAddOn>().getExpandedCard());
//                        print("Player Barriers: " + p.getBarriers());
//                    }
        
//            }//end Raycast IF
//        }//end Input IF
//    }//end SelectCard

//    public IEnumerator coroutineTest(Player p)
//    {
//        while(p.getBarriers() < 12)
//        {
//            selectCard(p);

//            yield return null;
//        }

//        print("add barriers is done");

//        yield return new WaitForSeconds(5f);

//        print("what happens now?");
//    }
//}
