﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

[ExecuteInEditMode]
public class changeFontscript : MonoBehaviour
{
   
	// Use this for initialization
	
	// Update is called once per frame
	void Update ()
    {
        int children = this.transform.childCount;
        Transform[] kids = new Transform[children];
        for (int i = 0; i < this.transform.childCount; i++)
        {
            kids[i] = this.transform.GetChild(i);
            Debug.Log(i);
        }

        for (int i = 0; i < kids.Length; i++)
        {
            //Text textbits = kids[i].GetComponent<Text>();
            //textbits.font = Resources.Load<Font>("Fonts/comics");
        }
        //Debug.Log(children);
	}
}
