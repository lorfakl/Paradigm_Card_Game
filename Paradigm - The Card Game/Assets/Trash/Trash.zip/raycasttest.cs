﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class raycasttest : MonoBehaviour {

	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {

        if (Input.GetMouseButtonUp(0))
        {
            print("input");
            Ray ray = Camera.main.ScreenPointToRay(Input.mousePosition);
            print("fired a ray");
            RaycastHit hit;
            if (Physics.Raycast(ray, out hit))
            {
                print("Something happened");
                GameObject shot = hit.transform.gameObject;
                print(shot.GetType());
            }
        }      
	}
}
