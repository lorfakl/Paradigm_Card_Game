﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GameManager : MonoBehaviour {

    public GameObject humanTurnScript; //empty game object that holds the human player scripts
    public GameObject aiTurnScript; //empty game object that holds the AI player scripts
    Player human = new Player(); 
    Player ai = new Player();
    bool initialSetup; //this bool is for things done only once per game
    StateTurnPattern humanTurn; //FSM turn object for human player
    AITurnPattern aiTurn; //FSM turn object for AI player

    // Use this for initialization
    void Awake ()  //these objects are placed in awake to set their values before everything else in the scene
    {

        humanTurn = humanTurnScript.GetComponent<StateTurnPattern>();
        humanTurn.currentState = humanTurn.barrierSelectState; //sets the first state to barrierselect which is the first thing done every game
        aiTurn = aiTurnScript.GetComponent<AITurnPattern>();
        aiTurn.currentState = aiTurn.barrierSelectState; //sets the first state to barrierselect which is the first thing done every game
        initialSetup = false;
	}
	
	// Update is called once per frame
	void Update ()
    {
        Debug.Log("Current Phase" + initialSetup); //Debugging
        if (!initialSetup) //this happens only once, it allows the human player to select their barriers
        {
            humanTurn.currentState.UpdateState(); //runs updateState function for barrier selection
            
            if(human.isDoneSelectingBarriers()) //
            {
                initialSetup = true;
            }
        }
        territoryChallenge(human, ai);

        humanTurn.currentState.UpdateState(); //continues human turn (more logic needed)
        aiTurn.currentState.UpdateState(); //continues AI turn (more logic needed)

        //there will not be much more placed in update here all main implementation occurs in the State scripts

    }

    void territoryChallenge(Player p1, Player p2) //follows territory challenge rules (look at the rules)
    {
        Card p1TCLand = p1.getTCLandscapeCard();
        Card p2TCLand = p2.getTCLandscapeCard();
        
        if (p1TCLand.getAbility() == "Circle" && p2TCLand.getAbility() == "Square")
        {
            p1.setTCWinner(true);
        }
            else if(p1TCLand.getAbility() == "Circle" && p2TCLand.getAbility() == "Triangle")
            {
                p2.setTCWinner(true);
            }
                else if (p1TCLand.getAbility() == "Square" && p2TCLand.getAbility() == "Circle")
                {
                    p2.setTCWinner(true);
                }
                    else if (p1TCLand.getAbility() == "Square" && p2TCLand.getAbility() == "Triangle")
                    {
                        p1.setTCWinner(true);
                    }
                        else if (p1TCLand.getAbility() == "Triangle" && p2TCLand.getAbility() == "Circle")
                        {
                            p1.setTCWinner(true);
                        }
                            else if (p1TCLand.getAbility() == "Triangle" && p2TCLand.getAbility() == "Square")
                            {
                                p2.setTCWinner(true);
                            }
                                else if(p1TCLand.getAbility() == p2TCLand.getAbility())
                                {
                                    //choose landscape again
                                    p1.setTCWinner(true);
                                }

    }
    
    public Player sendAIPlayer(){ return ai;}
    public Player sendHumanPlayer() { return human; }
}
