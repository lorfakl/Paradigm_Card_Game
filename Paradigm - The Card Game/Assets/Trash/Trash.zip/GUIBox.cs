﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GUIBox : MonoBehaviour {

	// Use this for initialization
	void OnGUI ()
    {
        GUI.Box(new Rect(485, 63, 150, 70), "Fookin Boxes!");
	}
	
	// Update is called once per frame
	void Update () {
		
	}
}
